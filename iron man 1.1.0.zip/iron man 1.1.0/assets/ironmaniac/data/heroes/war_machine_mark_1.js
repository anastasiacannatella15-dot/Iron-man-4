function init(hero) {
    hero.setName("War Machine");
    hero.setTier(7);
	
    hero.setHelmet("item.superhero_armor.piece.helmet");
    hero.setChestplate("item.superhero_armor.piece.chestplate");
    hero.setLeggings("item.superhero_armor.piece.leggings");
    hero.setBoots("item.superhero_armor.piece.boots");

    hero.addPowers("ironmaniac:iron_man_armor_heavy_weaponry", "ironmaniac:iron_man_armor_base_fast");
    hero.addAttribute("PUNCH_DAMAGE", 8.0, 0);
    hero.addAttribute("WEAPON_DAMAGE", 1.0, 0);
    hero.addAttribute("FALL_RESISTANCE", 8.0, 0);
    hero.addAttribute("SPRINT_SPEED", 0.4, 1);

    hero.addKeyBind("AIM", "key.aim", 1);
    hero.addKeyBind("ENERGY_PROJECTION", "Machineguns", 2);
	hero.addKeyBind("CHARGED_BEAM", "Unibeam", 4);

    hero.setModifierEnabled(isModifierEnabled);
    hero.setKeyBindEnabled(isKeyBindEnabled);
    hero.setHasProperty(hasProperty);
    hero.supplyFunction("canAim", canAim);
    hero.setHasPermission(hasPermission);

    hero.addSoundEvent("MASK_OPEN", "fiskheroes:iron_man_mask_open");
    hero.addSoundEvent("MASK_CLOSE", "fiskheroes:iron_man_mask_close");
    hero.addSoundEvent("AIM_START", "fiskheroes:repulsor_charge");
    hero.addSoundEvent("AIM_STOP", "fiskheroes:repulsor_powerdown");
    hero.addSoundEvent("STEP", "fiskheroes:iron_man_walk");
    
    hero.setTickHandler((entity, manager) => {

        var flying = entity.getData("fiskheroes:flying");
        manager.incrementData(entity, "fiskheroes:dyn/booster_timer", 2, flying);

        manager.incrementData(entity, "ironmaniac:dyn/flap_timer", 6, flying);
	
        var flying = entity.getData("fiskheroes:flying");
        manager.incrementData(entity, "fiskheroes:dyn/booster_timer", 2, flying);

        var item = entity.getHeldItem();
        flying &= !entity.as("PLAYER").isUsingItem();
        manager.incrementData(entity, "fiskheroes:dyn/booster_r_timer", 2, flying && item.isEmpty() && !entity.isPunching() && entity.getData("fiskheroes:aiming_timer") == 0);
        manager.incrementData(entity, "fiskheroes:dyn/booster_l_timer", 2, flying && !item.doesNeedTwoHands());

        var t = entity.getData("fiskheroes:dyn/superhero_landing_ticks");

        if (t == 0 && !entity.isSprinting() && !entity.isOnGround() && entity.motionY() < -0.75 && entity.world().blockAt(entity.pos().add(0, -1.5, 0)).isSolid()) {
			manager.setData(entity, "fiskheroes:dyn/superhero_landing_ticks", t = 10);
            entity.playSound("fiskheroes:mob.ironman.hurt", 1, 0.8 + Math.random() * 0.2);
			
        }
        else if (t > 0) {
            manager.setData(entity, "fiskheroes:dyn/superhero_landing_ticks", --t);
        }
        manager.incrementData(entity, "fiskheroes:dyn/superhero_landing_timer", 2, 6, t > 0);
		
		var i;
		if(t == 10){
			i = Math.random();
			if (i < 0.5){
				manager.setData(entity, "ironmaniac:dyn/landing", 0);
			}
			else{
				manager.setData(entity, "ironmaniac:dyn/landing", 1);
			}
		}
    });
}

function isModifierEnabled(entity, modifier) {
    return modifier.name() != "fiskheroes:water_breathing" || !entity.getData("fiskheroes:mask_open");
}

function isKeyBindEnabled(entity, keyBind) {
    if (entity.isSprinting() && entity.getData("fiskheroes:flying")) {
        return false;
    }
    if (keyBind == "AIM") {
        return (entity.getInterpolatedData("fiskheroes:energy_projection_timer")==0 && !entity.getData('fiskheroes:beam_charging') && entity.getInterpolatedData('fiskheroes:beam_shooting') == 0);
    }
    if (keyBind == "ENERGY_PROJECTION") {
        return (entity.getInterpolatedData("fiskheroes:aimed_timer")==0 && !entity.getData('fiskheroes:beam_charging') && entity.getInterpolatedData('fiskheroes:beam_shooting') == 0);
    }
    if (keyBind == "CHARGED_BEAM") {
        return (entity.getInterpolatedData("fiskheroes:aimed_timer")==0 && entity.getInterpolatedData("fiskheroes:energy_projection_timer")==0);
    }
    return true;
}

function hasProperty(entity, property) {
    return property == "MASK_TOGGLE" || property == "BREATHE_SPACE" && !entity.getData("fiskheroes:mask_open");
}

function canAim(entity) {
    return entity.getHeldItem().isEmpty() || entity.getHeldItem().isGun() || entity.getHeldItem().name() == "fisktag:weapon";
}
function hasPermission(entity, permission) {
    return permission == "USE_FISKTAG_GUN";
}
