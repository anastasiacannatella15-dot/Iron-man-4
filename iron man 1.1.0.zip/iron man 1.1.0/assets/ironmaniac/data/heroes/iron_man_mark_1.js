var canFly = true;
var timer = 1;
function init(hero) {
    hero.setName("Iron Man\u00A7a\u00A7r");
    hero.setTier(5);

    hero.setHelmet("item.superhero_armor.piece.helmet");
    hero.setChestplate("item.superhero_armor.piece.chestplate");
    hero.setLeggings("item.superhero_armor.piece.leggings");
    hero.setBoots("item.superhero_armor.piece.boots");

     hero.addPowers("ironmaniac:iron_man_armor_base_mk1");
    hero.addAttribute("PUNCH_DAMAGE", 8.0, 0);
    hero.addAttribute("WEAPON_DAMAGE", 1.0, 0);
    hero.addAttribute("FALL_RESISTANCE", 8.0, 0);
    hero.addAttribute("BASE_SPEED", -0.1, 1);

    hero.addKeyBind("AIM", "Flamethrower", 1);

    hero.setModifierEnabled(isModifierEnabled);
    hero.setKeyBindEnabled(isKeyBindEnabled);
    hero.setHasProperty(hasProperty);
    hero.supplyFunction("canAim", canAim);
    hero.addSoundEvent("STEP", "ironmaniac:iron_man_mk1_walk");
    
    hero.setTickHandler((entity, manager) => {

        //timer = entity.getData("ironmaniac: dyn/mk1_timer");

        if (!entity.isOnGround() && (timer>= 1)) {
            timer--;
        }
        else if (entity.isOnGround() && timer <= 50) {
            timer++;
        }

        if (timer <= 1) {
            canFly = false;
        } else if (timer > 1) {
            canFly = true;
        }
        
        var t = entity.getData("fiskheroes:dyn/superhero_landing_ticks");

        if (t == 0 && !entity.isSprinting() && !entity.isOnGround() && entity.motionY() < -0.75 && entity.world().blockAt(entity.pos().add(0, -1.5, 0)).isSolid()) {
            manager.setData(entity, "fiskheroes:dyn/superhero_landing_ticks", t = 10);
        }
        else if (t > 0) {
            manager.setData(entity, "fiskheroes:dyn/superhero_landing_ticks", --t);
        }
        manager.incrementData(entity, "fiskheroes:dyn/superhero_landing_timer", 2, 6, t > 0);
        manager.setData(entity, "ironmaniac:dyn/mk1_timer", timer +1);        
    });
}

function isModifierEnabled(entity, modifier) {
    if (canFly) {
        return modifier.name() != "fiskheroes:jetpacking";
    }
    return false
}

function isKeyBindEnabled(entity, keyBind) {
    if (entity.isSprinting() && entity.getData("fiskheroes:flying")) {
        return false;
    }
    return true;
}

function hasProperty(entity, property) {
    return property == "MASK_TOGGLE" && property != "BREATHE_SPACE";
}

function canAim(entity) {
    return entity.getHeldItem().isEmpty();
}