function init(hero) {
    hero.setName("Iron Man\u00A7a\u00A7r");
    hero.setTier(6);
    
    hero.setChestplate("item.superhero_armor.piece.chestplate");
    
    hero.addPowers("ironmaniac:iron_man_armor_base" , "ironmaniac:iron_man_armor_suitcase");
    hero.addAttribute("PUNCH_DAMAGE", 7.0, 0);
	hero.addAttribute("WEAPON_DAMAGE", 1.0, 0);
    hero.addAttribute("FALL_RESISTANCE", 8.0, 0);
    
    hero.addKeyBind("AIM", "key.aim", 1);
	hero.addKeyBind("CHARGED_BEAM", "Unibeam", 4);
	hero.addKeyBind("NANITE_TRANSFORM", "Suit Up", 5);
    
    hero.addAttributeProfile("INACTIVE", inactiveProfile);
    hero.setAttributeProfile(getAttributeProfile);
    hero.setModifierEnabled(isModifierEnabled);
    hero.setKeyBindEnabled(isKeyBindEnabled);
    hero.setHasProperty(hasProperty);
    hero.setTierOverride(getTierOverride);
    hero.supplyFunction("canAim", canAim);

    hero.addSoundEvent("MASK_OPEN", "fiskheroes:iron_man_mask_open");
    hero.addSoundEvent("MASK_CLOSE", "fiskheroes:iron_man_mask_close");
    hero.addSoundEvent("AIM_START", "fiskheroes:repulsor_charge");
    hero.addSoundEvent("AIM_STOP", "fiskheroes:repulsor_powerdown");
    hero.addSoundEvent("STEP", "ironmaniac:mark_5_walk");

    hero.setTickHandler((entity, manager) => {

        hero.addSoundEvent("STEP", "fiskheroes:iron_man_walk");

        manager.incrementData(entity, "ironmaniac:dyn/shield_timer", 5, 5, entity.getData("fiskheroes:shield"));
        ice = entity.getData("ironmaniac:dyn/ice_timer");

        var flying = entity.getData("fiskheroes:flying");
        manager.incrementData(entity, "fiskheroes:dyn/booster_timer", 2, flying);

        var item = entity.getHeldItem();
        flying &= !entity.as("PLAYER").isUsingItem();
        manager.incrementData(entity, "fiskheroes:dyn/booster_r_timer", 2, flying && item.isEmpty() && !entity.isPunching() && entity.getData("fiskheroes:aiming_timer") == 0);
        manager.incrementData(entity, "fiskheroes:dyn/booster_l_timer", 2, flying && !item.doesNeedTwoHands());

        var t = entity.getData("fiskheroes:dyn/superhero_landing_ticks");

        if (t == 0 && !entity.isSprinting() && !entity.isOnGround() && entity.motionY() < -0.75 && entity.world().blockAt(entity.pos().add(0, -1.5, 0)).isSolid() && entity.getData("ironmaniac:dyn/mk5_timer") == 1) {
            manager.setData(entity, "fiskheroes:dyn/superhero_landing_ticks", t = 10);
            entity.playSound("fiskheroes:mob.ironman.hurt", 1, 0.8 + Math.random() * 0.2);

        }
        else if (t > 0) {
            manager.setData(entity, "fiskheroes:dyn/superhero_landing_ticks", --t);
        }
        manager.incrementData(entity, "fiskheroes:dyn/superhero_landing_timer", 2, 6, t > 0);

        var i;
        if (t == 10) {
            i = Math.random();
            if (i < 0.5) {
                manager.setData(entity, "ironmaniac:dyn/landing", 0);
            }
            else {
                manager.setData(entity, "ironmaniac:dyn/landing", 0);
            }
        }
    });
}

function getTierOverride(entity) {
    return entity.getData("ironmaniac:dyn/mk5") ? 5 : 0;
}

function inactiveProfile(profile) {
    profile.revokeAugments();
}

function getAttributeProfile(entity) {
    if (!entity.getData("ironmaniac:dyn/mk5")) {
        return "INACTIVE";
    }
    
    return entity.getData("fiskheroes:blade") ? "BLADE" : null;
}

function isModifierEnabled(entity, modifier) {
    if (modifier.name() != "fiskheroes:transformation" && modifier.name() != "fiskheroes:cooldown" && (entity.getData("ironmaniac:dyn/mk5_timer") <= 0.9) || modifier.name() == "fiskheroes:propelled_flight" && (entity.getData("ironmaniac:dyn/mk5_timer") <= 0.9)) {
        return false;
    }
  
    switch (modifier.name()) {
    case "fiskheroes:water_breathing":
            return !entity.getData("fiskheroes:mask_open") && entity.getData("ironmaniac:dyn/mk5");
    default:
        return true;
    }
}

function isKeyBindEnabled(entity, keyBind) {
    if (keyBind == "NANITE_TRANSFORM") {
        return entity.getData("fiskheroes:mask_open_timer") == 0;
    }
    else if (!entity.getData("ironmaniac:dyn/mk5")||entity.getData("ironmaniac:dyn/mk5_timer")<=0.9) {
        return false;
    }
    
    if (entity.getData("fiskheroes:flying")) {
        return false;
    }
    return true;
}

function hasProperty(entity, property) {
    switch (property) {
    case "MASK_TOGGLE":
            return entity.getData("ironmaniac:dyn/mk5_timer") == 1;
    case "BREATHE_SPACE":
            return !entity.getData("fiskheroes:mask_open") && entity.getData("ironmaniac:dyn/mk5");
    default:
        return false;
    }
}

function canAim(entity) {
    return entity.getHeldItem().isEmpty() && !entity.getData("fiskheroes:flying");
}