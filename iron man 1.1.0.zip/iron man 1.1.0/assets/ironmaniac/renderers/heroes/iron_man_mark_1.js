extend("ironmaniac:iron_man_base");
loadTextures({
    "layer1": "ironmaniac:mk1/iron_man_mark_1_layer_1",
    "layer2": "ironmaniac:mk1/iron_man_mark_1_layer_2",
    "lights_layer1": "ironmaniac:null",
    "lights_layer2": "ironmaniac:null",
    "lights_suit": "ironmaniac:null",
    "mask": "ironmaniac:null",
    "mask_lights": "ironmaniac:null",

    "model": "ironmaniac:mk1/mark_1_texture",
    "model_lights": "ironmaniac:mk1/mark_1_texture_lights"
});

var utils = implement("fiskheroes:external/utils");
var iron_man_helmet = implement("fiskheroes:external/iron_man_helmet");

var mk1 = implement("ironmaniac:external/mark_1");

var helmet;

var repulsor;
var metal_heat;


function initEffects(renderer) {
    repulsor = renderer.createEffect("fiskheroes:overlay");

    helmet = iron_man_helmet.createFaceplate(renderer, "mask", null);

    model = mk1.create(renderer, "model", "model_lights");

    metal_heat = renderer.createEffect("fiskheroes:metal_heat");
    metal_heat.includeEffects(helmet.effect);

    utils.addCameraShake(renderer, 0.015, 1.5, "fiskheroes:flight_boost_timer");
    
    utils.bindParticles(renderer, "ironmaniac:mk1").setCondition(entity => entity.getData("fiskheroes:jetpacking"));
    utils.bindBeam(renderer, "fiskheroes:repulsor_blast", "fiskheroes:repulsor_blast", "rightArm", 0xFFC462, [
        { "firstPerson": [-4.5, 3.75, -8.0], "offset": [-0.5, 9.0, 0.0], "size": [1.5, 1.5] }
    ]);
    utils.bindBeam(renderer, "fiskheroes:charged_beam", "fiskheroes:charged_beam", "body", 0xFFC462, [
        { "offset": [0.0, 3, -1.0], "size": [2.0, 2.0] }
    ]).setParticles(renderer.createResource("PARTICLE_EMITTER", "fiskheroes:impact_charged_beam"));
}

function hasFoldingHelmet() {
    return false;
}

function hasBootLights() {
    return false;
}

function initAnimations(renderer) {
    parent.initAnimations(renderer);
    //addAnimation(renderer, "basic.CHARGED_BEAM", "fiskheroes:dual_aiming").setData((entity, data) => data.load(Math.max(entity.getInterpolatedData("fiskheroes:beam_charge") * 4 - 2, 0) - Math.max(entity.getInterpolatedData("fiskheroes:beam_charge") * 4 - 3, 0)));

    renderer.removeCustomAnimation("basic.AIMING");
    renderer.removeCustomAnimation("iron_man.LAND");
    renderer.removeCustomAnimation("iron_man_landing");
    addAnimationWithData(renderer, "basic.AIMING", "fiskheroes:aiming_fpcorr", "fiskheroes:aiming_timer");

    addAnimation(renderer, "iron_man.FLIGHT", "fiskheroes:flight/iron_man.anim.json")
        .setData((entity, data) => {
            data.load(0, entity.getInterpolatedData("fiskheroes:flight_timer") * (1 - entity.getInterpolatedData("fiskheroes:dyn/superhero_landing_timer")));
            data.load(1, entity.getInterpolatedData("fiskheroes:flight_boost_timer"));
        })
        .priority = -10;

    renderer.reprioritizeDefaultAnimation("PUNCH", -9);
    renderer.reprioritizeDefaultAnimation("AIM_BOW", -9);
}

function render(entity, renderLayer, isFirstPersonArm) {

    if (!isFirstPersonArm) {
        if (renderLayer == "HELMET") {
            helmet.render(entity.getInterpolatedData("fiskheroes:mask_open_timer2"));
        }        
    }

    model.render(entity, renderLayer, isFirstPersonArm, false);

    metal_heat.opacity = entity.getInterpolatedData("fiskheroes:metal_heat");
    metal_heat.render();
}