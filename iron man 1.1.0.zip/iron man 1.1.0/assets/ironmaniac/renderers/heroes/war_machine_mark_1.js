extend("ironmaniac:iron_man_base");
loadTextures({
    "layer1": "ironmaniac:wmk1/war_machine_mark_1_layer_1",
    "layer2": "ironmaniac:wmk1/war_machine_mark_1_layer_2",
    "lights_layer1": "ironmaniac:wmk1/war_machine_mark_1_lights",
    "lights_layer2": "ironmaniac:null",
    "lights_suit": "ironmaniac:wmk1/war_machine_mark_1_lights",
    "suit": "ironmaniac:wmk1/war_machine_mark_1_layer_1",
    "mask": "ironmaniac:wmk1/war_machine_mark_1_mask",
    "mask_lights": "ironmaniac:wmk1/war_machine_mark_1_mask",
    "minigun": "ironmaniac:wmk1/war_machine_mark_1_mini_gun",
    "armgun": "ironmaniac:wmk1/war_machine_mark_1_arm_gun_1",  
    "chest": "ironmaniac:wmk1/war_machine_mark_1_texture",
    "chest_lights": "ironmaniac:wmk1/war_machine_mark_1_texture_lights",  
    "null": "ironmaniac:null"
});

var utils = implement("fiskheroes:external/utils");
var iron_man_boosters = implement("ironmaniac:external/war_machine_mark_1_boosters");
var iron_man_helmet = implement("fiskheroes:external/iron_man_helmet");
var war_machine_model = implement("ironmaniac:external/war_machine_mark_1");
war_machine_model.utils = utils;



var model;

var helmet;
var boosters;

var repulsor;
var metal_heat;


function initEffects(renderer) {

    repulsor = renderer.createEffect("fiskheroes:overlay");

    helmet = iron_man_helmet.createFaceplate(renderer, "mask", null);
    boosters = iron_man_boosters.create(renderer, "fiskheroes:repulsor_layer_%s", true);
    model = war_machine_model.create(renderer, "minigun", "armgun", "chest", "chest_lights");

    metal_heat = renderer.createEffect("fiskheroes:metal_heat");
    metal_heat.includeEffects(helmet.effect);

    utils.addCameraShake(renderer, 0.015, 1.5, "fiskheroes:flight_boost_timer");
    utils.bindParticles(renderer, "ironmaniac:war_machine").setCondition(entity => entity.getData("fiskheroes:flying"));
    utils.bindBeam(renderer, "fiskheroes:repulsor_blast", "fiskheroes:repulsor_blast", "rightArm", 0xFFC462, [
        { "firstPerson": [-4.5, 3.75, -8.0], "offset": [-0.5, 9.0, 0.0], "size": [1.5, 1.5] }
    ]);
	utils.bindBeam(renderer, "fiskheroes:charged_beam", "fiskheroes:charged_beam", "body", 0xFFC462, [
        { "offset": [0.0, 3, -1.0], "size": [2.0, 2.0] }        
    ]).setParticles(renderer.createResource("PARTICLE_EMITTER", "fiskheroes:impact_charged_beam"));

    utils.bindBeam(renderer, "fiskheroes:energy_projection", null, "rightArm", null, [
        { "size": [0.0, 0.0] }
    ]).setParticles(renderer.createResource("PARTICLE_EMITTER", "ironmaniac:impact_bullet"));

    var bullets_beam = renderer.createResource("BEAM_RENDERER", "ironmaniac:bullet");

    bullets2 = utils.createLines(renderer, bullets_beam, 0xffcc14, [
        { "start": [0.0, 0.0, 0.0], "end": [0.0, 256.0, 0.0], "size": [1.0, 1.0] }
    ]);
    bullets2.anchor.set("rightArm");
    bullets2.setOffset(1.0, 9.0, 3.0).setRotation(0.0, 0.0, 0.0).setScale(4.0);
    bullets2.mirror = true;
}

function initAnimations(renderer) {
    parent.initAnimations(renderer);
    utils.addAnimationEvent(renderer, "FLIGHT_DIVE", "fiskheroes:iron_man_dive");

    renderer.removeCustomAnimation("basic.ENERGY_PROJ");

    addAnimation(renderer, "basic.ENERGY_PROJ", "ironmaniac:dual_aiming").setData((entity, data) => {
        //data.load(entity.getInterpolatedData("fiskheroes:dyn/energy_projection_timer"))
        var charge = entity.getInterpolatedData("fiskheroes:beam_charge");
        data.load(Math.max(entity.getInterpolatedData("fiskheroes:energy_projection_timer"), 0));
    });

    addAnimation(renderer, "iron_man.FLIGHT", "fiskheroes:flight/iron_man.anim.json")
        .setData((entity, data) => {
            data.load(0, entity.getInterpolatedData("fiskheroes:flight_timer") * (1 - entity.getInterpolatedData("fiskheroes:dyn/superhero_landing_timer")));
            data.load(1, entity.getInterpolatedData("fiskheroes:flight_boost_timer"));
        })
        .priority = -10;

    addAnimationWithData(renderer, "iron_man.LAND", "fiskheroes:superhero_landing", "fiskheroes:dyn/superhero_landing_timer")
        .setCondition(entity => entity.getData("ironmaniac:dyn/landing") == 0)
        .priority = -8;

    addAnimationWithData(renderer, "iron_man_landing", "ironmaniac:iron_man_landing", "fiskheroes:dyn/superhero_landing_timer")
        .setCondition(entity => entity.getData("ironmaniac:dyn/landing") == 1)
        .priority = -8;

    renderer.reprioritizeDefaultAnimation("PUNCH", -9);
    renderer.reprioritizeDefaultAnimation("AIM_BOW", -9);
}

function hasFoldingHelmet() {
    return false;
}

function hasBootLights() {
    return false;
}

function render(entity, renderLayer, isFirstPersonArm) {
    boosters.render(entity, renderLayer, isFirstPersonArm, false);
 

    if (!isFirstPersonArm) {
        if (renderLayer == "HELMET") {
            helmet.render(entity.getInterpolatedData("fiskheroes:mask_open_timer2"));
        }
        else if (renderLayer == "CHESTPLATE") {
            repulsor.opacity = Math.max(Math.min(entity.getInterpolatedData("fiskheroes:aimed_timer") * 2, 1), entity.getInterpolatedData("fiskheroes:dyn/booster_r_timer")) *(1-entity.getInterpolatedData("fiskheroes:energy_projection_timer"));
            repulsor.texture.set(null, "repulsor");
            repulsor.render();
            repulsor.opacity = entity.getInterpolatedData("fiskheroes:dyn/booster_l_timer") *(1-entity.getInterpolatedData("fiskheroes:energy_projection_timer"));
            repulsor.texture.set(null, "repulsor_left");
            repulsor.render();
            model.render(entity);
        }
        else if (renderLayer == "BOOTS") {
            repulsor.opacity = entity.getInterpolatedData("fiskheroes:dyn/booster_timer");
            repulsor.texture.set(null, "repulsor_boots");
            repulsor.render();
        }
    }

    if (entity.getInterpolatedData("fiskheroes:energy_projection_timer") > 0.9 && entity.getData('fiskheroes:energy_projection') && entity.ticksExisted() % 2 >= 0 && entity.ticksExisted() % 2 < 1 ? 1 : 0) {
        bullets2.render();
    }          
       
    

    metal_heat.opacity = entity.getInterpolatedData("fiskheroes:metal_heat");
    metal_heat.render();
}