extend("ironmaniac:iron_man_base");
loadTextures({
    "layer1": "ironmaniac:mk4/iron_man_mark_4_layer1",
    "layer2": "ironmaniac:mk4/iron_man_mark_4_layer2",
    "lights_layer1": "ironmaniac:mk2/iron_man_mark_2_lights",
    "lights_layer2": "ironmaniac:null",
    "lights_suit": "ironmaniac:mk2/iron_man_mark_2_lights",
    "mask_top1": "ironmaniac:mk3/iron_man_mark_3_mask_true",
    "mask_bottom1": "ironmaniac:mk3/iron_man_mark_3_mask_bottom_true",
    "mask_top2": "ironmaniac:mk3/iron_man_mark_3_mask_false",
    "mask_bottom2": "ironmaniac:mk3/iron_man_mark_3_mask_bottom_false",
    "mask_lights": "ironmaniac:mk2/iron_man_mark_2_lights",
    "shield": "ironmaniac:mk3/mark_3_shield_texture",
    "null": "ironmaniac:null"
});

var utils = implement("fiskheroes:external/utils");
var iron_man_boosters = implement("ironmaniac:external/iron_man_boosters");
var iron_man_helmet = implement("ironmaniac:external/iron_man_helmet");
var iron_man_helmet2 = implement("ironmaniac:external/iron_man_helmet");

var mark_3_shield = implement("ironmaniac:external/mark_3_shield");


var helmet;
var helmet2;
var boosters;

var repulsor;
var metal_heat;

var shield;

function initEffects(renderer) {
    repulsor = renderer.createEffect("fiskheroes:overlay");

    helmet = iron_man_helmet.create(renderer, "mask_top1", "mask_bottom1");
    helmet2 = iron_man_helmet2.create(renderer, "mask_top2", "mask_bottom2");

    shield = mark_3_shield.create(renderer, "shield", "null");

    boosters = iron_man_boosters.create(renderer, "fiskheroes:repulsor_layer_%s", true);

    metal_heat = renderer.createEffect("fiskheroes:metal_heat");
    metal_heat.includeEffects(helmet.effect);

    utils.addCameraShake(renderer, 0.015, 1.5, "fiskheroes:flight_boost_timer");
    utils.bindParticles(renderer, "ironmaniac:iron_man").setCondition(entity => entity.getData("fiskheroes:flying"));
    utils.bindBeam(renderer, "fiskheroes:repulsor_blast", "fiskheroes:repulsor_blast", "rightArm", 0xFFC462, [
        { "firstPerson": [-4.5, 3.75, -8.0], "offset": [-0.5, 9.0, 0.0], "size": [1.5, 1.5] }
    ]);
    utils.bindBeam(renderer, "fiskheroes:charged_beam", "fiskheroes:charged_beam", "body", 0xFFC462, [
        { "offset": [0.0, 3, -1.0], "size": [2.0, 2.0] }
    ]).setParticles(renderer.createResource("PARTICLE_EMITTER", "fiskheroes:impact_charged_beam"));
}

function hasFoldingHelmet() {
    return false;
}

function hasBootLights() {
    return false;
}

function render(entity, renderLayer, isFirstPersonArm) {
    boosters.render(entity, renderLayer, isFirstPersonArm, false);

    if (!isFirstPersonArm) {
        if (renderLayer == "HELMET") {
            if (entity.getInterpolatedData("fiskheroes:mask_open_timer2") > 0) {
                helmet.render(entity.getInterpolatedData("fiskheroes:mask_open_timer2"));
            }
            else {
                helmet2.render(entity.getInterpolatedData("fiskheroes:mask_open_timer2"));
            }
        }
        else if (renderLayer == "CHESTPLATE") {
            repulsor.opacity = Math.max(Math.min(entity.getInterpolatedData("fiskheroes:aimed_timer") * 2, 1), entity.getInterpolatedData("fiskheroes:dyn/booster_r_timer"));
            repulsor.texture.set(null, "repulsor");
            repulsor.render();
            repulsor.opacity = entity.getInterpolatedData("fiskheroes:dyn/booster_l_timer");
            repulsor.texture.set(null, "repulsor_left");
            repulsor.render();
        }
        else if (renderLayer == "BOOTS") {
            repulsor.opacity = entity.getInterpolatedData("fiskheroes:dyn/booster_timer");
            repulsor.texture.set(null, "repulsor_boots");
            repulsor.render();
        }
    }
    if (entity.getData("ironmaniac:dyn/shield_timer") != 0) {
        shield.render();
    }
    metal_heat.opacity = entity.getInterpolatedData("fiskheroes:metal_heat");
    metal_heat.render();
}