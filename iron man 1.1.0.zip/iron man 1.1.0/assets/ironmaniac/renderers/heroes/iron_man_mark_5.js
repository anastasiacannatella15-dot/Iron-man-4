extend("ironmaniac:iron_man_base");
loadTextures({
    "layer1": "ironmaniac:mk5/iron_man_mark_5_layer1",
    "layer2": "ironmaniac:mk5/iron_man_mark_5_layer1",
    "lights_layer1": "ironmaniac:mk5/iron_man_mark_5_lights",
    "lights_layer2": "ironmaniac:mk5/iron_man_mark_5_lights",
    "lights_suit": "ironmaniac:mk5/iron_man_mark_5_lights",
    "suit": "ironmaniac:mk5/iron_man_mark_5_suit.tx.json",
    "mask": "ironmaniac:mk5/iron_man_mark_5_mask_false",
    "mask_lights": "ironmaniac:mk5/iron_man_mark_5_mask_lights",
    "suitcase": "ironmaniac:mk5/mark_5_suitcase",
    "helmet": "ironmaniac:mk5/mark_5_helmet",
    "null": "ironmaniac:null"
});

var utils = implement("fiskheroes:external/utils");
var iron_man_helmet = implement("fiskheroes:external/iron_man_helmet");
var mark_5_helmet = implement("ironmaniac:external/mark_5_helmet");
var suitcase = implement("ironmaniac:external/suitcase");

var iron_man_boosters = implement("ironmaniac:external/iron_man_boosters");

var chest_model;

var helmet;
var boosters;

var repulsor;
var metal_heat;

function init(renderer) {
    parent.init(renderer);

    renderer.fixHatLayer("CHESTPLATE");

    renderer.setTexture((entity, renderLayer) => {
        if (!entity.is("DISPLAY")) {
            var timer = entity.getInterpolatedData("ironmaniac:dyn/mk5_timer");
            return (timer > 0 && entity.getInterpolatedData('ironmaniac:dyn/mk5_timer') > 0) ? "suit" : timer < 1 ? "null" : "layer1";
        }
        return "layer1";
    });
    renderer.setLights((entity, renderLayer) => {
        if ( entity.getData("fiskheroes:mask_open_timer2") == 0 && entity.getInterpolatedData('ironmaniac:dyn/mk5_timer') >=0.9) {
            return "mask_lights";
        }
        else if (entity.is("DISPLAY")) {
            return entity.getData("fiskheroes:mask_open_timer2") == 0 ? "mask_lights" : "lights_suit";
        }
        return (entity.getInterpolatedData('ironmaniac:dyn/mk5_timer') > 0.7) ? "lights_suit" : "null";
    });

    renderer.showModel("CHESTPLATE", "head", "headwear", "body", "rightArm", "leftArm", "rightLeg", "leftLeg");

}
function initEffects(renderer) {
    repulsor = renderer.createEffect("fiskheroes:overlay");

    suitcase_model = suitcase.create(renderer, "suitcase", null);
    helmet_model = mark_5_helmet.create(renderer, "helmet", null);

    helmet = iron_man_helmet.createFaceplate(renderer, "mask", null);
    boosters = iron_man_boosters.create(renderer, "fiskheroes:repulsor_layer_%s", true);

    metal_heat = renderer.createEffect("fiskheroes:metal_heat");
    metal_heat.includeEffects(helmet.effect);

    utils.addCameraShake(renderer, 0.015, 1.5, "fiskheroes:flight_boost_timer");
    utils.bindParticles(renderer, "ironmaniac:iron_man").setCondition(entity => entity.getData("fiskheroes:flying"));
    utils.bindBeam(renderer, "fiskheroes:repulsor_blast", "fiskheroes:repulsor_blast", "rightArm", 0xFFC462, [
        { "firstPerson": [-4.5, 3.75, -8.0], "offset": [-0.5, 9.0, 0.0], "size": [1.5, 1.5] }
    ]);
    utils.bindBeam(renderer, "fiskheroes:charged_beam", "fiskheroes:charged_beam", "body", 0xFFC462, [
        { "offset": [0.0, 3, -1.0], "size": [2.0, 2.0] }
    ]).setParticles(renderer.createResource("PARTICLE_EMITTER", "fiskheroes:impact_charged_beam"));
}

function hasFoldingHelmet() {
    return false;
}

function hasBootLights() {
    return false;
}

function initAnimations(renderer) {
    parent.initAnimations(renderer);
    //addAnimation(renderer, "basic.CHARGED_BEAM", "fiskheroes:dual_aiming").setData((entity, data) => data.load(Math.max(entity.getInterpolatedData("fiskheroes:beam_charge") * 4 - 2, 0) - Math.max(entity.getInterpolatedData("fiskheroes:beam_charge") * 4 - 3, 0)));

    //renderer.removeCustomAnimation("basic.AIMING");
    renderer.removeCustomAnimation("iron_man_landing");
    //addAnimationWithData(renderer, "basic.AIMING", "fiskheroes:aiming_fpcorr", "fiskheroes:aiming_timer");

    addAnimation(renderer, "iron_man.FLIGHT", "fiskheroes:flight/iron_man.anim.json")
        .setData((entity, data) => {
            data.load(0, entity.getInterpolatedData("fiskheroes:flight_timer") * (1 - entity.getInterpolatedData("fiskheroes:dyn/superhero_landing_timer")));
            data.load(1, entity.getInterpolatedData("fiskheroes:flight_boost_timer"));
        })
        .priority = -10;

    addAnimationWithData(renderer, "iron_man.SUITUP", "ironmaniac:mark_5_suitup_body", "ironmaniac:dyn/mk5_timer")
        //.setCondition(entity => entity.getInterpolatedData("fiskheroes:dyn/nanites") == true)
        .priority = -6;


    addAnimationWithData(renderer, "iron_man.LAND", "fiskheroes:superhero_landing", "fiskheroes:dyn/superhero_landing_timer")
        .priority = -8;

    renderer.reprioritizeDefaultAnimation("PUNCH", -9);
    renderer.reprioritizeDefaultAnimation("AIM_BOW", -9);
}

function render(entity, renderLayer, isFirstPersonArm) {

     boosters.render(entity, renderLayer, isFirstPersonArm, true);

    if (!isFirstPersonArm) {
        suitcase_model.render(entity);
        if (entity.getInterpolatedData('ironmaniac:dyn/mk5_timer') >= 0.9 || entity.is("DISPLAY")) {
           
                helmet.render(entity.getInterpolatedData("fiskheroes:mask_open_timer2"));
               
            
                repulsor.opacity = Math.max(Math.min(entity.getInterpolatedData("fiskheroes:aimed_timer") * 2, 1), entity.getInterpolatedData("fiskheroes:dyn/booster_r_timer"));
                repulsor.texture.set(null, "repulsor");
                repulsor.render();
                repulsor.opacity = entity.getInterpolatedData("fiskheroes:dyn/booster_l_timer");
                repulsor.texture.set(null, "repulsor_left");
                repulsor.render();
            
                repulsor.opacity = entity.getInterpolatedData("fiskheroes:dyn/booster_timer");
                repulsor.texture.set(null, "repulsor_boots");
                repulsor.render();
            
        }

        else if (!entity.is("DISPLAY")) {
            if (entity.getInterpolatedData('ironmaniac:dyn/mk5_timer') < 0.9 && entity.getInterpolatedData('ironmaniac:dyn/mk5_timer') > 0.7) {
                helmet_model.render(entity);
                }
                //if (entity.getInterpolatedData('ironmaniac:dyn/mk5_timer') < 0.7 && entity.getInterpolatedData('ironmaniac:dyn/mk5_timer') > 0) {
                //    suitcase_model.render(entity);
                //}
        }
    }


    metal_heat.opacity = entity.getInterpolatedData("fiskheroes:metal_heat");
    metal_heat.render();
}