
function create(renderer, texture, lights) {	

	var model_head = renderer.createResource("MODEL", "ironmaniac:mark_1_mask");
	model_head.bindAnimation("ironmaniac:iron_man_mark_1").setData((entity, data) => {
		data.load(entity.getInterpolatedData("fiskheroes:mask_open_timer2"));
	});
	model_head.texture.set(texture, lights);
	
    var model_body = renderer.createResource("MODEL", "ironmaniac:mark_1_body");
    model_body.texture.set(texture, lights);
	
	var model_rightArm = renderer.createResource("MODEL", "ironmaniac:mark_1_right_arm");
    model_rightArm.texture.set(texture, lights);

	var model_rightLeg = renderer.createResource("MODEL", "ironmaniac:mark_1_right_leg");
    model_rightLeg.texture.set(texture, lights);
	
	var model_leftLeg = renderer.createResource("MODEL", "ironmaniac:mark_1_left_leg");
	model_leftLeg.texture.set(texture, lights);

	var model_rightFoot = renderer.createResource("MODEL", "ironmaniac:mark_1_right_foot");
	model_rightFoot.texture.set(texture, lights);

	var model_leftFoot = renderer.createResource("MODEL", "ironmaniac:mark_1_left_foot");
	model_leftFoot.texture.set(texture, lights);

	
	body = renderer.createEffect("fiskheroes:model").setModel(model_body);
    body.anchor.set("body");
	body.setScale(1.025);

	head = renderer.createEffect("fiskheroes:model").setModel(model_head);
	head.anchor.set("head");
	head.setScale(1.01);
	head.setOffset(0.0, 0.04, 0.0);
	
	rightArm = renderer.createEffect("fiskheroes:model").setModel(model_rightArm);
    rightArm.anchor.set("rightArm");
	rightArm.setScale(1.01);
	rightArm.setOffset(-4.8, -1.55, 0.0);
	
	rightLeg = renderer.createEffect("fiskheroes:model").setModel(model_rightLeg);
	rightLeg.anchor.set("rightLeg");
	rightLeg.setScale(1.01);
	rightLeg.setOffset(-2.0, -12.0, 0.0);
	
	leftLeg = renderer.createEffect("fiskheroes:model").setModel(model_leftLeg);
    leftLeg.anchor.set("leftLeg");
	leftLeg.setScale(1.01);
	leftLeg.setOffset(2.0, -12.0, 0.0);

	rightFoot = renderer.createEffect("fiskheroes:model").setModel(model_rightFoot);
	rightFoot.anchor.set("rightLeg");
	rightFoot.setScale(1.01);
	rightFoot.setOffset(-2.0, -12.0, 0.0);

	leftFoot = renderer.createEffect("fiskheroes:model").setModel(model_leftFoot);
	leftFoot.anchor.set("leftLeg");
	leftFoot.setScale(1.01);
	leftFoot.setOffset(2.0, -12.0, 0.0);

	return {

		head: head,
		body: body,
		rightArm: rightArm,
		rightLeg: rightLeg,
		leftLeg: leftLeg,
		rightFoot: rightFoot,
		leftFoot: leftFoot,
		render: (entity, renderLayer, isFirstPersonArm, all) => {
			if (!isFirstPersonArm) {
				//&& entity.isWearingFullSuit()
				if (all || renderLayer == "HELMET") {
					head.render();
				}
				else if (all || renderLayer == "CHESTPLATE") {
					body.render();
					rightArm.render();
				}
				else if (all || renderLayer == "LEGGINGS") {
					rightLeg.render();
					leftLeg.render();
				}
				else if (all || renderLayer == "BOOTS") {
					rightFoot.render();
					leftFoot.render();
				}
			}
		}
	
		
			//if (!entity.isDisplayStand()) {
				//head.render();
				
				
				//leftArm.render();
				//rightLeg.render();
				//leftLeg.render();
			//}
			//else
				//display.render();		
		
	};

}
