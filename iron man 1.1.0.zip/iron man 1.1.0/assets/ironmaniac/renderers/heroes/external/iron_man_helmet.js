
function create(renderer, top_1, bottom_1) {

    var effect;
    var effect2;


    effect = renderer.createEffect("fiskheroes:opening_mask");
    effect.texture.set(top_1);
    effect.setOffset(0.0, -3.25, -6.0).setRotation(-70.0, 0.0, 0.0);
    effect.anchor.set("head");

    effect2 = renderer.createEffect("fiskheroes:opening_mask");
    effect2.texture.set(bottom_1);
    effect2.setOffset(0.0, -1.0, 0.01).setRotation(25.0, 0.0, 0.0);
    effect2.anchor.set("head");

    return {
        effect: effect,
        render: timer => {
            effect.progress = timer;
            effect.render();
            effect2.progress = timer;
            effect2.render();
        }
    };
}
