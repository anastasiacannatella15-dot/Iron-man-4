function create(renderer, texture, lights) {
    var suitcase;
    var suitcase_hand;

    var model = renderer.createResource("MODEL", "ironmaniac:mark_5_suitcase");
    model.bindAnimation("ironmaniac:mark_5_suitup").setData((entity, data) => {
        data.load(entity.getInterpolatedData("ironmaniac:dyn/mk5_timer"));
    });
    model.texture.set(texture, lights);
    suitcase = renderer.createEffect("fiskheroes:model").setModel(model);
    suitcase.anchor.set("body");

    suitcase_hand = renderer.createEffect("fiskheroes:model").setModel(model);
    suitcase_hand.anchor.set("rightArm");
    return {
        render: entity => {
            if (!entity.is("DISPLAY")) {
                if (entity.getInterpolatedData('ironmaniac:dyn/mk5_timer') < 0.7 && entity.getInterpolatedData('ironmaniac:dyn/mk5_timer') > 0) {
                    suitcase.render();
                }
                else if (entity.getInterpolatedData('ironmaniac:dyn/mk5_timer') == 0){   
                    suitcase_hand.setRotation(-90,0,90);  
                    suitcase_hand.setOffset(-21,23,0);           
                    suitcase_hand.render();
                }
            }
        }
    };
}