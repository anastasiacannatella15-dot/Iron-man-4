var utils;
function create(renderer, minigun_texture, armgun_texture, chest_texture, chest_texture_lights) {
    var minigun;
    var armgun;    

    


    var minigun_model = renderer.createResource("MODEL", "ironmaniac:war_machine_mk1_mini_gun");
    minigun_model.texture.set(minigun_texture);
    minigun_model.bindAnimation("ironmaniac:war_machine_mark_1_minigun").setData((entity, data) => 
    {
        data.load(0, entity.getInterpolatedData("fiskheroes:flight_timer") * (1 - entity.getInterpolatedData("fiskheroes:dyn/superhero_landing_timer")));
        data.load(1, entity.getInterpolatedData("fiskheroes:flight_boost_timer"));
        data.load(2, entity.getInterpolatedData("fiskheroes:energy_projection_timer"));
    });
    minigun = renderer.createEffect("fiskheroes:model").setModel(minigun_model);
    minigun.anchor.set("body");
    minigun.setScale(1.1);
    //minigun.setOffset(6, -2, 3);

    var armgun_model = renderer.createResource("MODEL", "ironmaniac:war_machine_mk1_arm_gun_1");
    armgun_model.texture.set(armgun_texture);

    var chest_model = renderer.createResource("MODEL", "ironmaniac:war_machine_mark_1_chest");
    chest_model.texture.set(chest_texture, chest_texture_lights);
    chest_model.bindAnimation("ironmaniac:mark_7_chest_controlled_flight").setData((entity, data) => {
        data.load(0, Math.max(entity.getInterpolatedData("fiskheroes:levitate_timer"), entity.getInterpolatedData("ironmaniac:dyn/flap_timer")));
        data.load(1, entity.getInterpolatedData("fiskheroes:flight_boost_timer"));
    });
    chest = renderer.createEffect("fiskheroes:model").setModel(chest_model);
    chest.anchor.set("body");

    armgunR = renderer.createEffect("fiskheroes:model").setModel(armgun_model);
    armgunR.anchor.set("rightArm");
    armgunR.setOffset(2, 5, 3);
    armgunR.setRotation(0, 90, 0);

    armgunL = renderer.createEffect("fiskheroes:model").setModel(armgun_model);
    armgunL.anchor.set("leftArm");
    armgunL.setOffset(0, 5, 3);
    armgunL.setRotation(0, 90, 0);

    var bullets_beam = renderer.createResource("BEAM_RENDERER", "ironmaniac:bullet");

    bullets1 = utils.createLines(renderer, bullets_beam, 0xffcc14, [
        { "start": [0.0, 0.0, 0.0], "end": [0.0, 256.0, 0.0], "size": [1.0, 1.0] }
    ]);
    bullets1.anchor.set("body", minigun_model.getCubeOffset("shape144"));
    bullets1.setOffset(0.0, 0.0, 0.0).setRotation(90.0, 0.0, 0.0).setScale(4.0);

    bullets2 = utils.createLines(renderer, bullets_beam, 0xffcc14, [
        { "start": [0.0, 0.0, 0.0], "end": [0.0, 256.0, 0.0], "size": [1.0, 1.0] }
    ]);
    bullets2.anchor.set("rightArm");
    bullets2.setOffset(1.0, 9.0, 3.0).setRotation(0.0, 0.0, 0.0).setScale(4.0);
    bullets2.mirror = true;

    var fire = renderer.createResource("ICON", "fiskheroes:repulsor_layer_%s");

    var booster = renderer.createEffect("fiskheroes:booster");
    booster.setIcon(fire).setOffset(0.0, 0.0, 0.0).setRotation(90.0, 0.0, 0.0);
    booster.anchor.set("body", minigun_model.getCubeOffset("shape144"));   
    booster.speedScale = 0;
    booster.setScale(1.3);
    booster.opacity = 0.5;

    var booster2 = renderer.createEffect("fiskheroes:booster");
    booster2.setIcon(fire).setOffset(1.0, 9.0, 3.0).setRotation(0.0, 0.0, 0.0);
    booster2.anchor.set("rightArm");
    booster2.speedScale = 0;
    booster2.mirror = true;
    booster2.setScale(0.8);
    booster2.opacity = 0.5;



    return {
        render: (entity, renderLayer, isFirstPersonArm, all) => {
            if (entity.getInterpolatedData("fiskheroes:energy_projection_timer") > 0.9 && entity.getData('fiskheroes:energy_projection') && entity.ticksExisted() % 2 >= 0 && entity.ticksExisted() % 2 < 1 ? 1 : 0) {
                bullets2.render();
                if (!isFirstPersonArm) {
                    bullets1.render();
                    booster.render();
                    booster2.render();
                    //bullets3.render();
                    //bullets4.render();
                } //else
                    //bullets3.render();
            }
            chest.render();
            minigun.render();
            armgunR.render();
            armgunL.render();
        }
    };
}