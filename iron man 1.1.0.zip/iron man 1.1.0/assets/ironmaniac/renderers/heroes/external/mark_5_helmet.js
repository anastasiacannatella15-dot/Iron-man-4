function create(renderer, texture, lights) {
    var helmet;

    var model = renderer.createResource("MODEL", "ironmaniac:mark_5_helmet");
    model.texture.set(texture, lights);
    model.bindAnimation("ironmaniac:mark_5_helmet").setData((entity, data) => {
        data.load(entity.getInterpolatedData("ironmaniac:dyn/mk5_timer"));

        //data.load(entity.getInterpolatedData("fiskheroes:mask_open_timer2"));
    });
    helmet = renderer.createEffect("fiskheroes:model").setModel(model);
    helmet.anchor.set("head");
    helmet.setScale(1.01);
    return {
        render: entity => {
            helmet.render();
        }
    };
}