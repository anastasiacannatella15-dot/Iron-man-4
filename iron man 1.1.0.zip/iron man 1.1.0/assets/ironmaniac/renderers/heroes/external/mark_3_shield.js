function create(renderer, texture, lights) {
    var effect;

    var model = renderer.createResource("MODEL", "ironmaniac:mark_3_shield");
    model.texture.set(texture, lights);

    model.bindAnimation("ironmaniac:mark_3_shield").setData((entity, data) => {
        data.load(entity.getInterpolatedData("ironmaniac:dyn/shield_timer"));
    });

    effect = renderer.createEffect("fiskheroes:model").setModel(model);
    //effect.setScale(1.1);
    effect.setOffset(-0.5, -2.0, 0.0);
    effect.anchor.set("rightArm");
    return {
        effect: effect,
        render: entity => {
            effect.render();
        }
    };
}