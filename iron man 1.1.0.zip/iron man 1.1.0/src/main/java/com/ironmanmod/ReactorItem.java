package com.ironmanmod;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;

import java.util.function.Consumer;

/** Reattore Arc: si indossa nello slot del petto. Da indossato permette la trasformazione nanotech. */
public class ReactorItem extends ArmorItem {
    public final SuitMark mark;

    public ReactorItem(SuitMark mark) {
        super(ReactorMaterial.of(mark), ArmorItem.Type.CHESTPLATE,
                new Item.Properties().stacksTo(1).rarity(Rarity.EPIC).fireResistant());
        this.mark = mark;
    }

    @Override
    public <T extends LivingEntity> int damageItem(ItemStack stack, int amount, T entity, Consumer<T> onBroken) {
        return 0;
    }

    @Override
    public boolean isEnchantable(ItemStack stack) {
        return false;
    }

    @Override
    public boolean isBookEnchantable(ItemStack stack, ItemStack book) {
        return false;
    }
}
