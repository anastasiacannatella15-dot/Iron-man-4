package com.ironmanmod;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.crafting.Ingredient;

/** Materiale del Reattore Arc indossabile (nessuna difesa, solo l'aspetto sul petto). Una texture per modello. */
public enum ReactorMaterial implements ArmorMaterial {
    MARK_42(SuitMark.MARK_42),
    MARK_50(SuitMark.MARK_50),
    MARK_85(SuitMark.MARK_85);

    public final SuitMark mark;

    ReactorMaterial(SuitMark mark) {
        this.mark = mark;
    }

    public static ReactorMaterial of(SuitMark m) {
        return values()[m.ordinal()];
    }

    @Override
    public int getDurabilityForType(ArmorItem.Type type) {
        return 1;
    }

    @Override
    public int getDefenseForType(ArmorItem.Type type) {
        return 0;
    }

    @Override
    public int getEnchantmentValue() {
        return 0;
    }

    @Override
    public SoundEvent getEquipSound() {
        return SoundEvents.BEACON_ACTIVATE;
    }

    @Override
    public Ingredient getRepairIngredient() {
        return Ingredient.EMPTY;
    }

    @Override
    public String getName() {
        return IronManMod.MODID + ":reactor_" + mark.id;
    }

    @Override
    public float getToughness() {
        return 0f;
    }

    @Override
    public float getKnockbackResistance() {
        return 0f;
    }
}
