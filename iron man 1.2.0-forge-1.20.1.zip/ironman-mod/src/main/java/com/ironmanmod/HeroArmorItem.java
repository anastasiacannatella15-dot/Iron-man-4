package com.ironmanmod;

import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;

/** Pezzo di armatura normale (Mark 42): si craftta, si indossa a mano, ha durabilita' e si ripara. */
public class HeroArmorItem extends ArmorItem {
    public final SuitMark mark;

    public HeroArmorItem(SuitMark mark, ArmorItem.Type type) {
        super(mark, type, new Item.Properties().rarity(Rarity.RARE));
        this.mark = mark;
    }
}
