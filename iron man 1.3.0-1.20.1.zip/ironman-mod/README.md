# Iron Man Mod — Mark 42 / Mark 50 / Mark 85

Minecraft **1.20.1** · Forge **47.3.0** · Java **17**

## Come ottenere il .jar

**Metodo consigliato (con il wrapper Gradle ufficiale):**
1. Scarica il "Mdk" di Forge 1.20.1 (47.3.0) da https://files.minecraftforge.net e scompattalo.
2. Copia dentro la sua cartella il mio `src/` e il mio `build.gradle` (sovrascrivi quelli dell'MDK).
3. Apri un terminale nella cartella ed esegui:
   - Windows: `gradlew build`
   - Linux/Mac: `./gradlew build`
4. Il file finito è in `build/libs/ironmanmod-1.0.0.jar` → mettilo nella cartella `mods` di Minecraft.

**Alternativa:** con JDK 17 e Gradle 8.1.x installati, esegui `gradle build` direttamente in questa cartella.

## Modello 3D
Le armature usano un vero modello 3D (spalline, pettorali, ginocchiere, stivali, casco con mento e orecchie che sporgono dal corpo), senza librerie extra. Texture in `textures/models/armor/markXX_model.png`.

## Come si gioca

**Mark 42 — armatura normale, senza nanotech.** Si craftta pezzo per pezzo (diamanti + oro, stessa forma dell'armatura di diamante)
e si indossa a mano. Con tutti e 4 i pezzi addosso hai volo, repulsori e missili. Ha 20 punti armor, tenacia 2,5 e il 10% di danno in meno:
un po' meglio del diamante.

**Mark 50 e Mark 85 — nanotech.** Serve il **Reattore Arc** del modello, da **indossare nello slot del petto** (appare sul petto).
Il bottone di trasformazione compare in alto a sinistra solo da quando lo indossi.
- Reattore Mark 50: diamanti + oro + stella del Nether al centro (`DGD / GRG / DGD`)
- Reattore Mark 85: lingotti di netherite + stelle del Nether + blocchi di diamante + Reattore Mark 50 al centro (`NSN / DRD / NSN`)
- Con `requireReactor` nel config si imposta se il reattore e' obbligatorio.

**Tasti** (modificabili in Opzioni → Controlli → Iron Man):

| Tasto | Azione |
|-------|--------|
| **G** | Trasformati / rimuovi l'armatura (1,3 secondi: prima il corpetto, poi il resto) |
| **R** | Raggio di fuoco (repulsore) |
| **V** | Unibeam di fuoco (solo Mark 50 e 85) |
| **B** | Micro-missili di fuoco (4 / 6 / 8 bersagli) |
| **X** | Teletrasporto (serve la Gemma dello Spazio, Mark 85) |
| **K** | Pannello Gemme (Mark 85) |

**Volo**: doppio salto per volare. Tieni **Sprint + W** mentre voli per il volo supersonico. L'energia si consuma volando e sparando e si ricarica a terra.

## Protezione e danno

| | Mark 42 | Mark 50 | Mark 85 |
|---|---|---|---|
| Armor (casco/petto/gambali/stivali) | 3/8/6/3 = 20 | 3/8/6/3 = 20 | 3/8/6/3 = 20 |
| Tenacia | 2,5 | 3 (come la netherite) | 12 |
| Danno subito (extra) | -10% | normale | -75% (circa il doppio della netherite con Protezione IV) |
| Raggio di fuoco | 11 | 11 | 11 |
| Unibeam | no | 28 | 40 |
| Micro-missili | 4 | 6 | 8 |

Il raggio fa 11 danni e dà fuoco, come una spada di netherite con Affilatura V. Nota: in Minecraft diamante e netherite hanno entrambi 20 punti armor,
le differenze tra i modelli vengono quindi da tenacia e riduzione del danno.

## Gemme dell'Infinito (Mark 85)

Premi **K** con la Mark 85 indossata. Il pannello ha 1 slot **Nucleo** + 6 slot **Gemme**.
In alto a destra sullo schermo compare lo slot Nucleo con le gemme inserite.

- Potere: danni ×1.6 e Forza · Spazio: teletrasporto (X) · Realtà: rigenerazione
- Anima: ti curi colpendo · Tempo: velocità e cooldown dimezzati · Mente: evidenzia i mostri vicini
- Con tutte e 6 le gemme: danni ×2.5

Le gemme di questa mod si craftano con una stella del Nether circondata da 8 materiali
(ametista = Potere, lapislazzuli = Spazio, redstone = Realtà, blaze powder = Anima, smeraldo = Tempo, polvere di glowstone = Mente).

### Compatibilità con "Pugmeowla's Infinity Stone Core"
La mod ha ID `infinity` ed è già riconosciuta (serve anche Palladium 1.20.1-4.2.0 o superiore, come richiede quella mod).
Nel pannello della Mark 85:
- lo slot **Nucleo** accetta il Guanto (`infinity:infinity_gauntlet`) e gli altri item della mod;
- le sue gemme (`infinity:power_stone`, `space_stone`, `reality_stone`, `soul_stone`, `time_stone`, `mind_stone`)
  valgono come gemme e danno i poteri della Mark 85.
Gli ID riconosciuti si cambiano in `config/ironmanmod-common.toml` (`externalModIds`).

## Morte
Se muori senza keepInventory, l'armatura nanotech sparisce e droppano la tua armatura originale e le gemme.
