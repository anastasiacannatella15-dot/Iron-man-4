package com.ironmanmod;

import com.ironmanmod.net.Net;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.network.NetworkHooks;
import net.minecraftforge.network.PacketDistributor;
import org.joml.Vector3f;

/**
 * Tutto lo stato dell'armatura vive nei dati persistenti del giocatore (NBT "IronManMod"):
 * selected, active, phase (0 nulla / 1 formazione / 2 ritiro), t, energy, orig (armatura originale), gems, cd_*.
 */
public final class SuitData {
    public static final String ROOT = "IronManMod";

    static final EquipmentSlot[] SLOTS = {EquipmentSlot.FEET, EquipmentSlot.LEGS, EquipmentSlot.CHEST, EquipmentSlot.HEAD};
    static final ArmorItem.Type[] TYPES = {ArmorItem.Type.BOOTS, ArmorItem.Type.LEGGINGS, ArmorItem.Type.CHESTPLATE, ArmorItem.Type.HELMET};

    private static final DustParticleOptions GOLD = new DustParticleOptions(new Vector3f(1f, 0.75f, 0.15f), 1.1f);
    private static final DustParticleOptions RED = new DustParticleOptions(new Vector3f(0.85f, 0.1f, 0.12f), 1.1f);

    private SuitData() {
    }

    // ------------------------------------------------------------------ dati

    public static CompoundTag root(Player p) {
        CompoundTag pd = p.getPersistentData();
        if (!pd.contains(ROOT, Tag.TAG_COMPOUND)) pd.put(ROOT, new CompoundTag());
        return pd.getCompound(ROOT);
    }

    /** Il modello del Reattore Arc indossato nello slot del petto, altrimenti null. */
    public static SuitMark wornReactor(Player p) {
        ItemStack s = p.getItemBySlot(EquipmentSlot.CHEST);
        return s.getItem() instanceof ReactorItem ri ? ri.mark : null;
    }

    public static SuitMark selected(Player p) {
        SuitMark worn = wornReactor(p);
        if (worn != null) return worn;
        CompoundTag r = root(p);
        SuitMark m = r.contains("selected") ? SuitMark.byNumber(r.getInt("selected")) : null;
        return m != null ? m : SuitMark.MARK_42;
    }

    /** Il modello attualmente indossato a trasformazione completata, altrimenti null. */
    public static SuitMark activeMark(Player p) {
        CompoundTag r = root(p);
        if (r.getInt("phase") == 0 && r.getInt("active") > 0) return SuitMark.byNumber(r.getInt("active"));
        if (r.getInt("phase") == 0 && hasMk42Set(p)) return SuitMark.MARK_42;
        return null;
    }

    /** La Mark 42 e' un'armatura normale: i poteri valgono solo con tutti e 4 i pezzi indossati. */
    public static boolean hasMk42Set(Player p) {
        for (int i = 0; i < 4; i++) {
            if (p.getItemBySlot(SLOTS[i]).getItem() != IronManMod.ARMOR.get(SuitMark.MARK_42).get(TYPES[i]).get()) {
                return false;
            }
        }
        return true;
    }

    public static boolean owns(Player p, SuitMark m) {
        if (!Config.REQUIRE_REACTOR.get()) return true;
        return wornReactor(p) == m;
    }

    private static int ownedMask(Player p) {
        int mask = 0;
        for (SuitMark m : SuitMark.values()) {
            if (owns(p, m)) mask |= 1 << m.ordinal();
        }
        return mask;
    }

    public static void msg(ServerPlayer p, String key, Object... args) {
        p.displayClientMessage(Component.translatable(key, args), true);
    }

    public static boolean isSuit(ItemStack s) {
        return s.getItem() instanceof SuitArmorItem;
    }

    // ------------------------------------------------------------------ azioni dai tasti

    public static void handleAction(ServerPlayer p, int action) {
        switch (action) {
            case Net.A_TRANSFORM -> toggle(p);
            case Net.A_CYCLE -> cycle(p);
            case Net.A_REPULSOR -> Powers.repulsor(p);
            case Net.A_UNIBEAM -> Powers.unibeam(p);
            case Net.A_MISSILES -> Powers.missiles(p);
            case Net.A_SPACE -> Powers.spaceJump(p);
            case Net.A_PANEL -> openPanel(p);
            default -> {
            }
        }
    }

    private static void cycle(ServerPlayer p) {
        CompoundTag r = root(p);
        if (r.getInt("phase") != 0 || r.getInt("active") > 0) {
            msg(p, "msg.ironmanmod.remove_first");
            return;
        }
        SuitMark[] all = SuitMark.values();
        int cur = selected(p).ordinal();
        for (int i = 1; i <= all.length; i++) {
            SuitMark c = all[(cur + i) % all.length];
            if (owns(p, c)) {
                r.putInt("selected", c.number);
                msg(p, "msg.ironmanmod.selected", c.number);
                return;
            }
        }
        msg(p, "msg.ironmanmod.need_reactor", selected(p).number);
    }

    private static void toggle(ServerPlayer p) {
        CompoundTag r = root(p);
        if (r.getInt("phase") != 0) return;

        if (r.getInt("active") == 0) {
            SuitMark m = wornReactor(p); // la nanotech parte solo con il Reattore Arc Mark 50 / 85 indossato
            if (m == null) {
                msg(p, "msg.ironmanmod.need_reactor_any");
                return;
            }
            // salva l'armatura originale e svuota gli slot (niente duplicazioni)
            ListTag orig = new ListTag();
            for (int i = 0; i < 4; i++) {
                CompoundTag t = new CompoundTag();
                p.getItemBySlot(SLOTS[i]).save(t);
                t.putByte("Slot", (byte) i);
                orig.add(t);
                p.setItemSlot(SLOTS[i], ItemStack.EMPTY);
            }
            r.put("orig", orig);
            if (!r.contains("energy")) r.putInt("energy", m.maxEnergy);
            else r.putInt("energy", Math.min(r.getInt("energy"), m.maxEnergy));
            r.putInt("active", m.number);
            r.putInt("phase", 1);
            r.putInt("t", 0);
        } else {
            r.putInt("phase", 2);
            r.putInt("t", 0);
        }
    }

    private static void openPanel(ServerPlayer p) {
        if (activeMark(p) != SuitMark.MARK_85) {
            msg(p, "msg.ironmanmod.need_mk85");
            return;
        }
        NetworkHooks.openScreen(p, new SimpleMenuProvider(
                (id, inv, pl) -> new GemMenu(id, inv, loadGems(p)),
                Component.translatable("gui.ironmanmod.gems")));
    }

    // ------------------------------------------------------------------ tick

    public static void tick(ServerPlayer p) {
        CompoundTag r = root(p);
        int phase = r.getInt("phase");
        int active = r.getInt("active");

        if (phase == 1) formTick(p, r);
        else if (phase == 2) removeTick(p, r);
        else if (active > 0) suitTick(p, r, SuitMark.byNumber(active));
        else if (hasMk42Set(p)) suitTick(p, r, SuitMark.MARK_42);
        else if (r.getBoolean("fly")) revokeFlight(p, r); // tolta la Mark 42: niente piu' volo

        if (p.tickCount % 10 == 0) sync(p);
    }

    private static void nanoParticles(ServerLevel lvl, ServerPlayer p, int t, int dur, boolean forming) {
        double prog = (double) t / dur;
        if (!forming) prog = 1.0 - prog;
        double cy = p.getY() + 1.25; // la nanotech parte dal petto e si allarga a poco a poco
        for (int i = 0; i < 10; i++) {
            double a = p.getRandom().nextDouble() * Math.PI * 2.0;
            double rr = 0.25 + 0.55 * prog;
            double dy = (p.getRandom().nextDouble() - 0.5) * 2.0 * (0.25 + 0.95 * prog);
            lvl.sendParticles(ParticleTypes.ELECTRIC_SPARK, p.getX() + Math.cos(a) * rr, cy + dy,
                    p.getZ() + Math.sin(a) * rr, 1, 0.02, 0.02, 0.02, 0.02);
        }
        lvl.sendParticles(forming ? GOLD : RED, p.getX(), cy, p.getZ(), 8, 0.1 + 0.4 * prog, 0.5 + 0.5 * prog, 0.1 + 0.4 * prog, 0.0);
    }

    private static ItemStack suitStack(SuitMark m, int slotIdx) {
        return new ItemStack(IronManMod.ARMOR.get(m).get(TYPES[slotIdx]).get());
    }

    private static void formTick(ServerPlayer p, CompoundTag r) {
        SuitMark m = SuitMark.byNumber(r.getInt("active"));
        if (m == null) {
            r.putInt("phase", 0);
            r.putInt("active", 0);
            return;
        }
        int dur = Config.TRANSFORM_TICKS.get();
        int t = r.getInt("t") + 1;
        r.putInt("t", t);
        ServerLevel lvl = p.serverLevel();

        p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 5, 4, false, false, false));
        nanoParticles(lvl, p, t, dur, true);

        if (t == 1) {
            lvl.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.BEACON_ACTIVATE, SoundSource.PLAYERS, 1.0f, 1.5f);
        }
        // prima il corpetto, poi gambali, stivali e per ultimo il casco (indici: 0 stivali, 1 gambali, 2 petto, 3 casco)
        int[] order = {2, 1, 0, 3};
        double[] at = {0.20, 0.45, 0.65, 0.85};
        for (int k = 0; k < 4; k++) {
            if (t == Math.max(1, (int) Math.round(dur * at[k]))) {
                p.setItemSlot(SLOTS[order[k]], suitStack(m, order[k]));
                lvl.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.ARMOR_EQUIP_NETHERITE, SoundSource.PLAYERS, 1.0f, 1.3f);
            }
        }
        if (t >= dur) {
            r.putInt("phase", 0);
            r.putInt("t", 0);
            lvl.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.BEACON_POWER_SELECT, SoundSource.PLAYERS, 1.0f, 1.2f);
            lvl.sendParticles(ParticleTypes.FLASH, p.getX(), p.getY() + 1.0, p.getZ(), 1, 0, 0, 0, 0);
        }
    }

    private static void removeTick(ServerPlayer p, CompoundTag r) {
        int dur = Config.TRANSFORM_TICKS.get();
        int t = r.getInt("t") + 1;
        r.putInt("t", t);
        ServerLevel lvl = p.serverLevel();

        p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 5, 4, false, false, false));
        nanoParticles(lvl, p, t, dur, false);

        if (t == 1) {
            lvl.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.BEACON_DEACTIVATE, SoundSource.PLAYERS, 1.0f, 1.5f);
        }
        int[] order = {3, 0, 1}; // casco, stivali, gambali; il corpetto sparisce alla fine
        double[] at = {0.20, 0.40, 0.60};
        for (int k = 0; k < 3; k++) {
            if (t == Math.max(1, (int) Math.round(dur * at[k]))) {
                p.setItemSlot(SLOTS[order[k]], ItemStack.EMPTY);
                lvl.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.ARMOR_EQUIP_NETHERITE, SoundSource.PLAYERS, 1.0f, 0.8f);
            }
        }
        if (t >= dur) {
            for (int i = 0; i < 4; i++) {
                if (isSuit(p.getItemBySlot(SLOTS[i]))) p.setItemSlot(SLOTS[i], ItemStack.EMPTY);
            }
            restoreOriginals(p, r);
            r.putInt("phase", 0);
            r.putInt("t", 0);
            r.putInt("active", 0);
            revokeFlight(p, r);
        }
    }

    /** Rimette l'armatura che il giocatore aveva prima di trasformarsi. */
    public static void restoreOriginals(Player p, CompoundTag source) {
        ListTag orig = source.getList("orig", Tag.TAG_COMPOUND);
        for (int i = 0; i < 4; i++) {
            if (isSuit(p.getItemBySlot(SLOTS[i]))) p.setItemSlot(SLOTS[i], ItemStack.EMPTY);
        }
        for (Tag tag : orig) {
            CompoundTag c = (CompoundTag) tag;
            ItemStack s = ItemStack.of(c);
            int i = c.getByte("Slot");
            if (s.isEmpty() || i < 0 || i > 3) continue;
            if (p.getItemBySlot(SLOTS[i]).isEmpty()) {
                p.setItemSlot(SLOTS[i], s);
            } else if (!p.getInventory().add(s)) {
                p.drop(s, false);
            }
        }
        source.remove("orig");
    }

    private static void revokeFlight(ServerPlayer p, CompoundTag r) {
        if (r.getBoolean("fly") && !p.isCreative() && !p.isSpectator()) {
            net.minecraft.world.entity.player.Abilities ab = p.getAbilities();
            ab.mayfly = false;
            ab.flying = false;
            ab.setFlyingSpeed(0.05f);
            p.onUpdateAbilities();
        }
        r.putBoolean("fly", false);
    }

    /** Impedisce di togliere/perdere i pezzi nanotech mentre l'armatura e' attiva. */
    private static void enforce(ServerPlayer p, SuitMark m) {
        for (int i = 0; i < 4; i++) {
            ItemStack cur = p.getItemBySlot(SLOTS[i]);
            if (cur.getItem() != IronManMod.ARMOR.get(m).get(TYPES[i]).get()) {
                p.setItemSlot(SLOTS[i], suitStack(m, i));
            }
        }
        Inventory inv = p.getInventory();
        for (int i = 0; i < inv.items.size(); i++) {
            if (isSuit(inv.items.get(i))) inv.items.set(i, ItemStack.EMPTY);
        }
        for (int i = 0; i < inv.offhand.size(); i++) {
            if (isSuit(inv.offhand.get(i))) inv.offhand.set(i, ItemStack.EMPTY);
        }
        if (isSuit(p.containerMenu.getCarried())) p.containerMenu.setCarried(ItemStack.EMPTY);
    }

    private static void suitTick(ServerPlayer p, CompoundTag r, SuitMark m) {
        if (m == null) {
            r.putInt("active", 0);
            return;
        }
        if (m != SuitMark.MARK_42 && p.tickCount % 5 == 0) enforce(p, m); // la Mark 42 e' armatura normale

        boolean creative = p.isCreative() || p.isSpectator();
        net.minecraft.world.entity.player.Abilities ab = p.getAbilities();
        int e = r.getInt("energy");

        if (!creative) {
            boolean flying = ab.flying && !p.onGround();
            if (flying) e -= p.isSprinting() ? 4 : 1;
            else if (p.onGround()) e += 4;
            else e += 1;
            e = Mth.clamp(e, 0, m.maxEnergy);

            boolean can = ab.mayfly ? e > 0 : e >= 100;
            if (ab.mayfly != can || Math.abs(ab.getFlyingSpeed() - m.flySpeed) > 1.0E-4f) {
                ab.mayfly = can;
                if (!can) ab.flying = false;
                ab.setFlyingSpeed(m.flySpeed);
                p.onUpdateAbilities();
            }
            r.putBoolean("fly", true);
        }
        r.putInt("energy", e);

        if (p.tickCount % 20 == 0) {
            // visore del casco
            p.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 300, 0, true, false, false));

            if (m == SuitMark.MARK_85) {
                boolean[] g = gems(p);
                if (g[0]) p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 60, 1, true, false, false));
                if (g[2]) p.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 60, 1, true, false, false));
                if (g[4]) p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 60, 1, true, false, false));
                if (g[5] && p.tickCount % 40 == 0) {
                    for (LivingEntity le : p.level().getEntitiesOfClass(LivingEntity.class,
                            p.getBoundingBox().inflate(24), x -> x instanceof Enemy && x.isAlive())) {
                        le.addEffect(new MobEffectInstance(MobEffects.GLOWING, 80, 0, true, false, false));
                    }
                }
            }
        }
    }

    // ------------------------------------------------------------------ energia / cooldown

    public static boolean useEnergy(ServerPlayer p, int cost) {
        if (p.isCreative()) return true;
        CompoundTag r = root(p);
        int e = r.getInt("energy");
        if (e < cost) return false;
        r.putInt("energy", e - cost);
        return true;
    }

    public static boolean ready(ServerPlayer p, String key) {
        return p.level().getGameTime() >= root(p).getLong("cd_" + key);
    }

    public static void setCooldown(ServerPlayer p, String key, int ticks) {
        if (gems(p)[4]) ticks = Math.max(1, ticks / 2); // Gemma del Tempo
        root(p).putLong("cd_" + key, p.level().getGameTime() + ticks);
    }

    // ------------------------------------------------------------------ gemme

    /** Gemme inserite (solo se si indossa la Mark 85). Indici: potere, spazio, realta', anima, tempo, mente. */
    public static boolean[] gems(Player p) {
        boolean[] g = new boolean[6];
        if (activeMark(p) != SuitMark.MARK_85) return g;
        ListTag l = root(p).getList("gems", Tag.TAG_COMPOUND);
        for (Tag t : l) {
            CompoundTag c = (CompoundTag) t;
            if (c.getByte("Slot") < 1) continue; // lo slot 0 e' il Nucleo
            int idx = GemRules.gemIndex(ItemStack.of(c));
            if (idx >= 0) g[idx] = true;
        }
        return g;
    }

    public static float damageMult(Player p) {
        boolean[] g = gems(p);
        int n = 0;
        for (boolean b : g) if (b) n++;
        if (n == 6) return 2.5f;
        return g[0] ? 1.6f : 1.0f;
    }

    public static void saveGems(Player p, SimpleContainer c) {
        ListTag list = new ListTag();
        for (int i = 0; i < c.getContainerSize(); i++) {
            if (c.getItem(i).isEmpty()) continue;
            CompoundTag t = new CompoundTag();
            c.getItem(i).save(t);
            t.putByte("Slot", (byte) i);
            list.add(t);
        }
        root(p).put("gems", list);
    }

    public static SimpleContainer loadGems(Player p) {
        return new SuitGemContainer(p);
    }

    /** Contenitore del pannello: salva da solo ogni modifica nei dati del giocatore. */
    public static class SuitGemContainer extends SimpleContainer {
        private final Player owner;
        private boolean loading = true;

        public SuitGemContainer(Player owner) {
            super(GemMenu.SLOTS);
            this.owner = owner;
            for (Tag t : root(owner).getList("gems", Tag.TAG_COMPOUND)) {
                CompoundTag c = (CompoundTag) t;
                int s = c.getByte("Slot");
                if (s >= 0 && s < GemMenu.SLOTS) setItem(s, ItemStack.of(c));
            }
            loading = false;
        }

        @Override
        public void setChanged() {
            super.setChanged();
            if (!loading && owner != null) saveGems(owner, this);
        }
    }

    // ------------------------------------------------------------------ sync verso il client

    public static void sync(ServerPlayer p) {
        CompoundTag r = root(p);
        int active = r.getInt("active");
        if (active == 0 && r.getInt("phase") == 0 && hasMk42Set(p)) active = 42;
        SuitMark sel = selected(p);
        SuitMark shown = active > 0 && SuitMark.byNumber(active) != null ? SuitMark.byNumber(active) : sel;

        ItemStack[] st = new ItemStack[7];
        for (int i = 0; i < 7; i++) st[i] = ItemStack.EMPTY;
        for (Tag t : r.getList("gems", Tag.TAG_COMPOUND)) {
            CompoundTag c = (CompoundTag) t;
            int s = c.getByte("Slot");
            if (s >= 0 && s < 7) st[s] = ItemStack.of(c);
        }
        int energy = r.contains("energy") ? r.getInt("energy") : shown.maxEnergy;
        Net.CH.send(PacketDistributor.PLAYER.with(() -> p),
                new Net.SyncPacket(active, sel.number, r.getInt("phase"), r.getInt("t"),
                        Config.TRANSFORM_TICKS.get(), energy, shown.maxEnergy, ownedMask(p),
                        GemRules.externalPresent(), st));
    }
}
