package com.ironmanmod.client;

import com.ironmanmod.IronManMod;
import com.ironmanmod.SuitMark;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.resources.ResourceLocation;

import java.util.EnumMap;
import java.util.Map;

/** Modelli 3D delle armature: piastre che sporgono dal corpo (geometria in ModelData). */
public final class SuitModels {
    public static final EquipmentSlot[] SLOTS = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
    private static final String[] PARTS = {"head", "hat", "body", "right_arm", "left_arm", "right_leg", "left_leg"};
    private static final Map<SuitMark, Map<EquipmentSlot, HumanoidModel<LivingEntity>>> CACHE = new EnumMap<>(SuitMark.class);

    private SuitModels() {
    }

    public static ModelLayerLocation loc(SuitMark m, EquipmentSlot s) {
        return new ModelLayerLocation(new ResourceLocation(IronManMod.MODID, m.id + "_" + s.getName()), "main");
    }

    private static float[] pivot(String part) {
        return switch (part) {
            case "right_arm" -> new float[]{-5f, 2f, 0f};
            case "left_arm" -> new float[]{5f, 2f, 0f};
            case "right_leg" -> new float[]{-1.9f, 12f, 0f};
            case "left_leg" -> new float[]{1.9f, 12f, 0f};
            default -> new float[]{0f, 0f, 0f};
        };
    }

    public static LayerDefinition create(SuitMark m, EquipmentSlot s) {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        ModelData.Cube[] cubes = ModelData.cubes(m.id, s.getName());
        for (String part : PARTS) {
            CubeListBuilder b = CubeListBuilder.create();
            for (ModelData.Cube c : cubes) {
                if (c.part().equals(part)) {
                    b.texOffs(c.u(), c.v()).addBox(c.x(), c.y(), c.z(), c.w(), c.h(), c.d(), new CubeDeformation(c.inflate()));
                }
            }
            float[] p = pivot(part);
            root.addOrReplaceChild(part, b, PartPose.offset(p[0], p[1], p[2]));
        }
        return LayerDefinition.create(mesh, ModelData.TEX, ModelData.TEX);
    }

    public static HumanoidModel<LivingEntity> get(SuitMark m, EquipmentSlot s) {
        return CACHE.computeIfAbsent(m, k -> new EnumMap<>(EquipmentSlot.class))
                .computeIfAbsent(s, k -> new HumanoidModel<>(Minecraft.getInstance().getEntityModels().bakeLayer(loc(m, s))));
    }
}
