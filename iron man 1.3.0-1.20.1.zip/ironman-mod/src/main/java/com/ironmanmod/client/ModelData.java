package com.ironmanmod.client;

/** GENERATO: geometria dei modelli 3D delle armature (coordinate del modello umanoide di Minecraft). */
public final class ModelData {
    public static final int TEX = 128;

    public record Cube(String part, int u, int v, float x, float y, float z, int w, int h, int d, float inflate) {
    }

    private ModelData() {
    }

    public static Cube[] cubes(String mark, String slot) {
        return switch (mark + "_" + slot) {
            case "mark42_head" -> new Cube[]{
                new Cube("head", 0, 0, -4f, -8f, -4f, 8, 8, 8, 0.5f),
                new Cube("head", 52, 54, -2f, -1.6f, -5.4f, 4, 2, 1, 0.0f),
                new Cube("head", 84, 41, -5.2f, -5.2f, -1.5f, 1, 3, 3, 0.0f),
                new Cube("head", 92, 41, 4.2f, -5.2f, -1.5f, 1, 3, 3, 0.0f),
                new Cube("head", 114, 25, -0.5f, -9.0f, -3.0f, 1, 1, 6, 0.0f),
                new Cube("head", 0, 34, -3f, -7.2f, 4.0f, 6, 6, 1, 0.0f)
            };
            case "mark42_chest" -> new Cube[]{
                new Cube("body", 32, 0, -4f, 0f, -2f, 8, 12, 4, 0.5f),
                new Cube("body", 100, 41, -3f, -1.4f, -2.5f, 6, 1, 5, 0.0f),
                new Cube("body", 96, 48, -3.7f, 1.0f, -3.4f, 3, 3, 1, 0.0f),
                new Cube("body", 104, 48, 0.7000000000000002f, 1.0f, -3.4f, 3, 3, 1, 0.0f),
                new Cube("body", 112, 48, -1.5f, 1.2f, -3.9f, 3, 3, 1, 0.0f),
                new Cube("body", 0, 58, -2.6f, 4.4f, -3.2f, 5, 1, 1, 0.0f),
                new Cube("body", 12, 58, -2.4f, 6.0f, -3.2f, 5, 1, 1, 0.0f),
                new Cube("body", 24, 58, -2.0f, 7.6f, -3.2f, 4, 1, 1, 0.0f),
                new Cube("body", 0, 16, -4.9f, 2f, -1.5f, 1, 6, 3, 0.0f),
                new Cube("body", 8, 16, 3.9000000000000004f, 2f, -1.5f, 1, 6, 3, 0.0f),
                new Cube("body", 0, 48, -3.5f, 1f, 2.4f, 7, 5, 1, 0.0f),
                new Cube("body", 120, 0, -0.5f, 0.5f, 3.3f, 1, 9, 1, 0.0f),
                new Cube("right_arm", 56, 0, -3f, -2f, -2f, 4, 12, 4, 0.4f),
                new Cube("left_arm", 72, 0, -1f, -2f, -2f, 4, 12, 4, 0.4f),
                new Cube("right_arm", 16, 16, -4f, -3.6f, -3f, 6, 3, 6, 0.2f),
                new Cube("left_arm", 40, 16, -2f, -3.6f, -3f, 6, 3, 6, 0.2f),
                new Cube("right_arm", 14, 34, -3.5f, -0.8f, -2.5f, 5, 2, 5, 0.0f),
                new Cube("left_arm", 34, 34, -1.5f, -0.8f, -2.5f, 5, 2, 5, 0.0f),
                new Cube("right_arm", 54, 34, -3.5f, 3.4f, -2.5f, 5, 2, 5, 0.0f),
                new Cube("left_arm", 74, 34, -1.5f, 3.4f, -2.5f, 5, 2, 5, 0.0f),
                new Cube("right_arm", 64, 16, -3.5f, 5.6f, -2.5f, 5, 4, 5, 0.0f),
                new Cube("left_arm", 84, 16, -1.5f, 5.6f, -2.5f, 5, 4, 5, 0.0f),
                new Cube("right_arm", 94, 34, -3.5f, 9.6f, -2.5f, 5, 2, 5, 0.0f),
                new Cube("left_arm", 0, 41, -1.5f, 9.6f, -2.5f, 5, 2, 5, 0.0f)
            };
            case "mark42_legs" -> new Cube[]{
                new Cube("body", 20, 41, -4f, 9f, -2f, 8, 3, 4, 0.3f),
                new Cube("body", 52, 25, -4.5f, 9.4f, -3f, 9, 2, 6, 0.0f),
                new Cube("body", 62, 54, -1.5f, 10.8f, -3.2f, 3, 2, 1, 0.0f),
                new Cube("right_leg", 88, 0, -2f, 0f, -2f, 4, 9, 4, 0.35f),
                new Cube("left_leg", 104, 0, -2f, 0f, -2f, 4, 9, 4, 0.35f),
                new Cube("right_leg", 16, 48, -2.5f, 0.4f, -3.0f, 5, 5, 1, 0.0f),
                new Cube("left_leg", 28, 48, -2.5f, 0.4f, -3.0f, 5, 5, 1, 0.0f),
                new Cube("right_leg", 0, 54, -2.5f, 4.8f, -3.3f, 5, 2, 2, 0.0f),
                new Cube("left_leg", 14, 54, -2.5f, 4.8f, -3.3f, 5, 2, 2, 0.0f),
                new Cube("right_leg", 28, 54, -2.5f, 6.8f, -3.0f, 5, 3, 1, 0.0f),
                new Cube("left_leg", 40, 54, -2.5f, 6.8f, -3.0f, 5, 3, 1, 0.0f),
                new Cube("right_leg", 40, 48, -2.5f, 5.0f, 2.1f, 5, 4, 1, 0.0f),
                new Cube("left_leg", 52, 48, -2.5f, 5.0f, 2.1f, 5, 4, 1, 0.0f)
            };
            case "mark42_feet" -> new Cube[]{
                new Cube("right_leg", 82, 25, -2f, 8f, -2f, 4, 4, 4, 0.55f),
                new Cube("left_leg", 98, 25, -2f, 8f, -2f, 4, 4, 4, 0.55f),
                new Cube("right_leg", 44, 41, -2.6f, 8.0f, -2.6f, 5, 2, 5, 0.0f),
                new Cube("left_leg", 64, 41, -2.4f, 8.0f, -2.6f, 5, 2, 5, 0.0f),
                new Cube("right_leg", 70, 54, -2.5f, 8.6f, -3.0f, 5, 2, 1, 0.0f),
                new Cube("left_leg", 82, 54, -2.5f, 8.6f, -3.0f, 5, 2, 1, 0.0f),
                new Cube("right_leg", 64, 48, -2.5f, 10.2f, -5.0f, 5, 2, 3, 0.0f),
                new Cube("left_leg", 80, 48, -2.5f, 10.2f, -5.0f, 5, 2, 3, 0.0f),
                new Cube("right_leg", 94, 54, -2.5f, 9.6f, 2.2f, 5, 2, 1, 0.0f),
                new Cube("left_leg", 106, 54, -2.5f, 9.6f, 2.2f, 5, 2, 1, 0.0f),
                new Cube("right_leg", 0, 25, -2.6f, 11.2f, -5.2f, 5, 1, 8, 0.0f),
                new Cube("left_leg", 26, 25, -2.4f, 11.2f, -5.2f, 5, 1, 8, 0.0f)
            };
            case "mark50_head" -> new Cube[]{
                new Cube("head", 0, 0, -4f, -8f, -4f, 8, 8, 8, 0.5f),
                new Cube("head", 52, 55, -2f, -1.6f, -5.4f, 4, 2, 1, 0.0f),
                new Cube("head", 84, 42, -5.2f, -5.2f, -1.5f, 1, 3, 3, 0.0f),
                new Cube("head", 92, 42, 4.2f, -5.2f, -1.5f, 1, 3, 3, 0.0f),
                new Cube("head", 114, 26, -0.5f, -9.0f, -3.0f, 1, 1, 6, 0.0f),
                new Cube("head", 0, 35, -3f, -7.2f, 4.0f, 6, 6, 1, 0.0f),
                new Cube("head", 0, 59, -3.5f, -6.3f, -5.0f, 7, 1, 1, 0.0f)
            };
            case "mark50_chest" -> new Cube[]{
                new Cube("body", 32, 0, -4f, 0f, -2f, 8, 12, 4, 0.5f),
                new Cube("body", 100, 42, -3f, -1.4f, -2.5f, 6, 1, 5, 0.0f),
                new Cube("body", 96, 49, -3.7f, 1.0f, -3.4f, 3, 3, 1, 0.0f),
                new Cube("body", 104, 49, 0.7000000000000002f, 1.0f, -3.4f, 3, 3, 1, 0.0f),
                new Cube("body", 112, 49, -1.5f, 1.2f, -3.9f, 3, 3, 1, 0.0f),
                new Cube("body", 16, 59, -2.6f, 4.4f, -3.2f, 5, 1, 1, 0.0f),
                new Cube("body", 28, 59, -2.4f, 6.0f, -3.2f, 5, 1, 1, 0.0f),
                new Cube("body", 40, 59, -2.0f, 7.6f, -3.2f, 4, 1, 1, 0.0f),
                new Cube("body", 24, 16, -4.9f, 2f, -1.5f, 1, 6, 3, 0.0f),
                new Cube("body", 32, 16, 3.9000000000000004f, 2f, -1.5f, 1, 6, 3, 0.0f),
                new Cube("body", 0, 49, -3.5f, 1f, 2.4f, 7, 5, 1, 0.0f),
                new Cube("body", 120, 0, -0.5f, 0.5f, 3.3f, 1, 9, 1, 0.0f),
                new Cube("right_arm", 56, 0, -3f, -2f, -2f, 4, 12, 4, 0.4f),
                new Cube("left_arm", 72, 0, -1f, -2f, -2f, 4, 12, 4, 0.4f),
                new Cube("right_arm", 40, 16, -4f, -3.6f, -3f, 6, 3, 6, 0.2f),
                new Cube("left_arm", 64, 16, -2f, -3.6f, -3f, 6, 3, 6, 0.2f),
                new Cube("right_arm", 14, 35, -3.5f, -0.8f, -2.5f, 5, 2, 5, 0.0f),
                new Cube("left_arm", 34, 35, -1.5f, -0.8f, -2.5f, 5, 2, 5, 0.0f),
                new Cube("right_arm", 54, 35, -3.5f, 3.4f, -2.5f, 5, 2, 5, 0.0f),
                new Cube("left_arm", 74, 35, -1.5f, 3.4f, -2.5f, 5, 2, 5, 0.0f),
                new Cube("right_arm", 88, 16, -3.5f, 5.6f, -2.5f, 5, 4, 5, 0.0f),
                new Cube("left_arm", 108, 16, -1.5f, 5.6f, -2.5f, 5, 4, 5, 0.0f),
                new Cube("right_arm", 94, 35, -3.5f, 9.6f, -2.5f, 5, 2, 5, 0.0f),
                new Cube("left_arm", 0, 42, -1.5f, 9.6f, -2.5f, 5, 2, 5, 0.0f)
            };
            case "mark50_legs" -> new Cube[]{
                new Cube("body", 20, 42, -4f, 9f, -2f, 8, 3, 4, 0.3f),
                new Cube("body", 52, 26, -4.5f, 9.4f, -3f, 9, 2, 6, 0.0f),
                new Cube("body", 62, 55, -1.5f, 10.8f, -3.2f, 3, 2, 1, 0.0f),
                new Cube("right_leg", 88, 0, -2f, 0f, -2f, 4, 9, 4, 0.35f),
                new Cube("left_leg", 104, 0, -2f, 0f, -2f, 4, 9, 4, 0.35f),
                new Cube("right_leg", 16, 49, -2.5f, 0.4f, -3.0f, 5, 5, 1, 0.0f),
                new Cube("left_leg", 28, 49, -2.5f, 0.4f, -3.0f, 5, 5, 1, 0.0f),
                new Cube("right_leg", 0, 16, -3.2f, 0.2f, -2.5f, 1, 5, 5, 0.0f),
                new Cube("left_leg", 12, 16, 2.2f, 0.2f, -2.5f, 1, 5, 5, 0.0f),
                new Cube("right_leg", 0, 55, -2.5f, 4.8f, -3.3f, 5, 2, 2, 0.0f),
                new Cube("left_leg", 14, 55, -2.5f, 4.8f, -3.3f, 5, 2, 2, 0.0f),
                new Cube("right_leg", 28, 55, -2.5f, 6.8f, -3.0f, 5, 3, 1, 0.0f),
                new Cube("left_leg", 40, 55, -2.5f, 6.8f, -3.0f, 5, 3, 1, 0.0f),
                new Cube("right_leg", 40, 49, -2.5f, 5.0f, 2.1f, 5, 4, 1, 0.0f),
                new Cube("left_leg", 52, 49, -2.5f, 5.0f, 2.1f, 5, 4, 1, 0.0f)
            };
            case "mark50_feet" -> new Cube[]{
                new Cube("right_leg", 82, 26, -2f, 8f, -2f, 4, 4, 4, 0.55f),
                new Cube("left_leg", 98, 26, -2f, 8f, -2f, 4, 4, 4, 0.55f),
                new Cube("right_leg", 44, 42, -2.6f, 8.0f, -2.6f, 5, 2, 5, 0.0f),
                new Cube("left_leg", 64, 42, -2.4f, 8.0f, -2.6f, 5, 2, 5, 0.0f),
                new Cube("right_leg", 70, 55, -2.5f, 8.6f, -3.0f, 5, 2, 1, 0.0f),
                new Cube("left_leg", 82, 55, -2.5f, 8.6f, -3.0f, 5, 2, 1, 0.0f),
                new Cube("right_leg", 64, 49, -2.5f, 10.2f, -5.0f, 5, 2, 3, 0.0f),
                new Cube("left_leg", 80, 49, -2.5f, 10.2f, -5.0f, 5, 2, 3, 0.0f),
                new Cube("right_leg", 94, 55, -2.5f, 9.6f, 2.2f, 5, 2, 1, 0.0f),
                new Cube("left_leg", 106, 55, -2.5f, 9.6f, 2.2f, 5, 2, 1, 0.0f),
                new Cube("right_leg", 0, 26, -2.6f, 11.2f, -5.2f, 5, 1, 8, 0.0f),
                new Cube("left_leg", 26, 26, -2.4f, 11.2f, -5.2f, 5, 1, 8, 0.0f)
            };
            case "mark85_head" -> new Cube[]{
                new Cube("head", 0, 0, -4f, -8f, -4f, 8, 8, 8, 0.5f),
                new Cube("head", 52, 55, -2f, -1.6f, -5.4f, 4, 2, 1, 0.0f),
                new Cube("head", 84, 42, -5.2f, -5.2f, -1.5f, 1, 3, 3, 0.0f),
                new Cube("head", 92, 42, 4.2f, -5.2f, -1.5f, 1, 3, 3, 0.0f),
                new Cube("head", 114, 26, -0.5f, -9.0f, -3.0f, 1, 1, 6, 0.0f),
                new Cube("head", 0, 35, -3f, -7.2f, 4.0f, 6, 6, 1, 0.0f),
                new Cube("head", 0, 59, -3.5f, -6.3f, -5.0f, 7, 1, 1, 0.0f)
            };
            case "mark85_chest" -> new Cube[]{
                new Cube("body", 32, 0, -4f, 0f, -2f, 8, 12, 4, 0.5f),
                new Cube("body", 100, 42, -3f, -1.4f, -2.5f, 6, 1, 5, 0.0f),
                new Cube("body", 96, 49, -3.7f, 1.0f, -3.4f, 3, 3, 1, 0.0f),
                new Cube("body", 104, 49, 0.7000000000000002f, 1.0f, -3.4f, 3, 3, 1, 0.0f),
                new Cube("body", 112, 49, -1.5f, 1.2f, -3.9f, 3, 3, 1, 0.0f),
                new Cube("body", 16, 59, -2.6f, 4.4f, -3.2f, 5, 1, 1, 0.0f),
                new Cube("body", 28, 59, -2.4f, 6.0f, -3.2f, 5, 1, 1, 0.0f),
                new Cube("body", 40, 59, -2.0f, 7.6f, -3.2f, 4, 1, 1, 0.0f),
                new Cube("body", 24, 16, -4.9f, 2f, -1.5f, 1, 6, 3, 0.0f),
                new Cube("body", 32, 16, 3.9000000000000004f, 2f, -1.5f, 1, 6, 3, 0.0f),
                new Cube("body", 0, 49, -3.5f, 1f, 2.4f, 7, 5, 1, 0.0f),
                new Cube("body", 120, 0, -0.5f, 0.5f, 3.3f, 1, 9, 1, 0.0f),
                new Cube("right_arm", 56, 0, -3f, -2f, -2f, 4, 12, 4, 0.4f),
                new Cube("left_arm", 72, 0, -1f, -2f, -2f, 4, 12, 4, 0.4f),
                new Cube("right_arm", 40, 16, -4f, -3.6f, -3f, 6, 3, 6, 0.2f),
                new Cube("left_arm", 64, 16, -2f, -3.6f, -3f, 6, 3, 6, 0.2f),
                new Cube("right_arm", 14, 35, -3.5f, -0.8f, -2.5f, 5, 2, 5, 0.0f),
                new Cube("left_arm", 34, 35, -1.5f, -0.8f, -2.5f, 5, 2, 5, 0.0f),
                new Cube("right_arm", 54, 35, -3.5f, 3.4f, -2.5f, 5, 2, 5, 0.0f),
                new Cube("left_arm", 74, 35, -1.5f, 3.4f, -2.5f, 5, 2, 5, 0.0f),
                new Cube("right_arm", 88, 16, -3.5f, 5.6f, -2.5f, 5, 4, 5, 0.0f),
                new Cube("left_arm", 108, 16, -1.5f, 5.6f, -2.5f, 5, 4, 5, 0.0f),
                new Cube("right_arm", 94, 35, -3.5f, 9.6f, -2.5f, 5, 2, 5, 0.0f),
                new Cube("left_arm", 0, 42, -1.5f, 9.6f, -2.5f, 5, 2, 5, 0.0f)
            };
            case "mark85_legs" -> new Cube[]{
                new Cube("body", 20, 42, -4f, 9f, -2f, 8, 3, 4, 0.3f),
                new Cube("body", 52, 26, -4.5f, 9.4f, -3f, 9, 2, 6, 0.0f),
                new Cube("body", 62, 55, -1.5f, 10.8f, -3.2f, 3, 2, 1, 0.0f),
                new Cube("right_leg", 88, 0, -2f, 0f, -2f, 4, 9, 4, 0.35f),
                new Cube("left_leg", 104, 0, -2f, 0f, -2f, 4, 9, 4, 0.35f),
                new Cube("right_leg", 16, 49, -2.5f, 0.4f, -3.0f, 5, 5, 1, 0.0f),
                new Cube("left_leg", 28, 49, -2.5f, 0.4f, -3.0f, 5, 5, 1, 0.0f),
                new Cube("right_leg", 0, 16, -3.2f, 0.2f, -2.5f, 1, 5, 5, 0.0f),
                new Cube("left_leg", 12, 16, 2.2f, 0.2f, -2.5f, 1, 5, 5, 0.0f),
                new Cube("right_leg", 0, 55, -2.5f, 4.8f, -3.3f, 5, 2, 2, 0.0f),
                new Cube("left_leg", 14, 55, -2.5f, 4.8f, -3.3f, 5, 2, 2, 0.0f),
                new Cube("right_leg", 28, 55, -2.5f, 6.8f, -3.0f, 5, 3, 1, 0.0f),
                new Cube("left_leg", 40, 55, -2.5f, 6.8f, -3.0f, 5, 3, 1, 0.0f),
                new Cube("right_leg", 40, 49, -2.5f, 5.0f, 2.1f, 5, 4, 1, 0.0f),
                new Cube("left_leg", 52, 49, -2.5f, 5.0f, 2.1f, 5, 4, 1, 0.0f)
            };
            case "mark85_feet" -> new Cube[]{
                new Cube("right_leg", 82, 26, -2f, 8f, -2f, 4, 4, 4, 0.55f),
                new Cube("left_leg", 98, 26, -2f, 8f, -2f, 4, 4, 4, 0.55f),
                new Cube("right_leg", 44, 42, -2.6f, 8.0f, -2.6f, 5, 2, 5, 0.0f),
                new Cube("left_leg", 64, 42, -2.4f, 8.0f, -2.6f, 5, 2, 5, 0.0f),
                new Cube("right_leg", 70, 55, -2.5f, 8.6f, -3.0f, 5, 2, 1, 0.0f),
                new Cube("left_leg", 82, 55, -2.5f, 8.6f, -3.0f, 5, 2, 1, 0.0f),
                new Cube("right_leg", 64, 49, -2.5f, 10.2f, -5.0f, 5, 2, 3, 0.0f),
                new Cube("left_leg", 80, 49, -2.5f, 10.2f, -5.0f, 5, 2, 3, 0.0f),
                new Cube("right_leg", 94, 55, -2.5f, 9.6f, 2.2f, 5, 2, 1, 0.0f),
                new Cube("left_leg", 106, 55, -2.5f, 9.6f, 2.2f, 5, 2, 1, 0.0f),
                new Cube("right_leg", 0, 26, -2.6f, 11.2f, -5.2f, 5, 1, 8, 0.0f),
                new Cube("left_leg", 26, 26, -2.4f, 11.2f, -5.2f, 5, 1, 8, 0.0f)
            };
            default -> new Cube[0];
        };
    }
}
